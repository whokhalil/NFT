function FilteredPage() {
  
}

export default FilteredPage;
